ADS1115 info :
    https://learn.adafruit.com/raspberry-pi-analog-to-digital-converters/ads1015-slash-ads1115
    
ADS1115 Code (not sure):
    https://github.com/eclipse/upm/blob/master/examples/python/ads1115.py
    
AD8232 Code (not sure):
    https://github.com/eclipse/upm/blob/master/examples/python/ad8232.py
    
 ADS1115 _Potintiometer
   https://howchoo.com/pi/how-to-install-a-potentiometer-on-a-raspberry-pi
